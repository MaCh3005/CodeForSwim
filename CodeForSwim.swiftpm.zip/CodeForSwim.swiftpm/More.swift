//
//  More.swift
//  CodeForSwim
//
//  Created by iOS UNAM 07 on 01/03/23.
//

import SwiftUI

struct More: View {
    var body: some View {
        
        VStack{
            
            Text("MORE")
                .font(.largeTitle)
                .fontWeight(.heavy)
            
            Divider()
    
            Text("Hi my name is Miguel and it is my app")
                .font(.subheadline)
                .foregroundColor(.gray)
            Spacer()
            
            Text("MACH")
                .font(.title)
                .foregroundColor(.black)
                .fontWeight(.bold)
        }
        

    }
}

struct More_Previews: PreviewProvider {
    static var previews: some View {
        More()
    }
}
