//
//  SwimImage.swift
//  CodeForSwim
//
//  Created by iOS UNAM 07 on 01/03/23.
//

import SwiftUI

struct SwimImage: View {
    var body: some View {
        
        Image("mariposa")
            .resizable()
            .frame(width : 350, height: 350)
            .clipShape(Circle())
            .overlay{
                Circle().stroke(.gray, lineWidth: 6)
            }
            .shadow(radius: 10)
        
    }
}

struct SwimImage_Previews: PreviewProvider {
    static var previews: some View {
        SwimImage()
    }
}
