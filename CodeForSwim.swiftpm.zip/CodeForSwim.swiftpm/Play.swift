//
//  Play.swift
//  CodeForSwim
//
//  Created by iOS UNAM 07 on 01/03/23.
//

import SwiftUI

struct Play: View {
    var body: some View {
        VStack{
            
            Text("LEVELS")
                .font(.largeTitle)
                .fontWeight(.heavy)
            
            Divider()
            
            HStack{
                
                Button{
                    // ACCION DEL BOTON
                } label: {
                    NavigationLink(destination: Level1()){
                        Text("LVL 1")
                            .foregroundColor(.black)
                            .font(.title)
                            .bold()
                    }
                }
                Divider()
                    .frame(height: 20)
                
                Button{
                    // ACCION DEL BOTON
                } label: {
                    NavigationLink(destination: More()){
                        Text("LVL2")
                            .foregroundColor(.black)
                            .font(.title)
                            .bold()
                    }
                }
                
            }
    
            Spacer()
            
            Text("MACH")
                .font(.title)
                .foregroundColor(.black)
                .fontWeight(.bold)
        }
        
        
    }    }


struct Play_Previews: PreviewProvider {
    static var previews: some View {
        Play()
    }
}
