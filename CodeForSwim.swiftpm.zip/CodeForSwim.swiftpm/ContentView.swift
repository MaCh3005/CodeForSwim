import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView{
            
            VStack{
                Text("CODE FOR SWIM")
                    .font(.largeTitle)
                    .fontWeight(.heavy)
                    .foregroundColor(.black)
                
                SwimImage()
                    .offset(y: 80)
                    .padding(.bottom, 150)
                
                //Spacer()
                
                HStack{
                    
                    Button{
                        // ACCION DEL BOTON
                    } label: {
                        NavigationLink(destination: Play()){
                            Text("PLAY")
                                .foregroundColor(.black)
                                .font(.title)
                                .bold()
                        }
                    }
                    Divider()
                        .frame(height: 20)
                    
                    Button{
                        // ACCION DEL BOTON
                    } label: {
                        NavigationLink(destination: More()){
                            Text("MORE")
                                .foregroundColor(.black)
                                .font(.title)
                                .bold()
                        }
                    }
                    
                }
                
                
                
                
            }
            .padding(50)
            Spacer()
            
            
        }
    }
    
}


