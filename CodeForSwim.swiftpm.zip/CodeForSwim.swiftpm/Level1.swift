//
//  Level1.swift
//  CodeForSwim
//
//  Created by iOS UNAM 07 on 01/03/23.
//

import SwiftUI

struct Level1: View {
    var body: some View {
        VStack{
            
            Text("LEVEL 1")
                .font(.largeTitle)
                .fontWeight(.heavy)
            
            Divider()
                .offset(y: -20)
                .frame(width: 220)
    
            Text("PRINT:")
                .font(.title2)
                .foregroundColor(.black)
                .fontWeight(.bold)
                .offset(y: -20)
            Text("We use the print() function in swift to write a string to standar output.")
                .font(.subheadline)
                .foregroundColor(.gray)
                .offset(y: -15)
            Text("EXAMPLE:")
                .font(.title2)
                .foregroundColor(.black)
                .fontWeight(.bold)
                .offset(y: -20)
            Text("print('Hello World')")
            
            
            
            Spacer()
            
            
            
            
        }
        

    }
    }


struct Level1_Previews: PreviewProvider {
    static var previews: some View {
        Level1()
    }
}
